<html>
<body>

<?php
    $servername = "localhost";
    $username = "root";
    $password = "abcd1234";
    $dbname = "web200";
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) 
    {
        die("Connection failed: " . mysqli_connect_error());
    }

    if(isset($_POST['login']) && !empty($_POST['login']))
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM users WHERE username='$username' AND password='$password' limit 1";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) == 0)
            echo 'Invalid username or password';
        else{

            while ($row = mysqli_fetch_array($result)) {
                $u1   = $row['username'];
                echo "<h1><tr>Hello: <td>$u1</td></h1>";
            }
            echo '<p>Login Success, Oops but I dont have flag, find it pls....</p>';
        }
    }
?>
        <form action="" method="post">
            Username: <input type="text" name="username"/><br />
            Password: <input type="password" name="password"/><br />
            <input type="submit" name="login" value="Login"/>
        </form>

</body>
</html>
